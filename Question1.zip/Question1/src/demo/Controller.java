    package demo;

    import java.io.IOException;
    import java.io.PrintWriter;
    import java.sql.Connection;
    import java.sql.DriverManager;
    import java.sql.PreparedStatement;
    import java.sql.ResultSet;
    import java.sql.SQLException;
    import java.sql.Statement;

    import javax.servlet.ServletException;
    import javax.servlet.http.HttpServlet;
    import javax.servlet.http.HttpServletRequest;
    import javax.servlet.http.HttpServletResponse;



    public class Controller extends HttpServlet 
    {
        private static final long serialVersionUID = 1L;


        public Controller() 
        {
            super();
        }


        protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
        {
        }


        protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
        {
            response.setContentType("text/html");
            PrintWriter out=response.getWriter();

            String fn = request.getParameter("fname");
    		String ln = request.getParameter("lname");
    		String em = request.getParameter("email");
    		String ph = request.getParameter("phone");
    		String lo = request.getParameter("location");
    		

        }


        public  void view() throws ClassNotFoundException
        {

            try
            {
                String url="jdbc:sqlserver://localhost:49520;databaseName=Q1;integratedSecurity=true";
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                Connection con = DriverManager.getConnection(url);
                Statement stmt=con.createStatement();
                ResultSet rs=stmt.executeQuery("select * from quest1");

                while(rs.next())
                {
                    rs.getString("fname");
                    rs.getString("lnamse");
                    rs.getString("email");
                    rs.getString("phone");
                    rs.getString("location");
                   System.out.println(rs.getString("fname"));

                }

            } 
            catch (SQLException e)
            {
                e.printStackTrace();
            }
            return;

        }

        public  String insertuser() throws SQLException
        {

            String sql = "insert into quest1 values(?,?,?,?,?)";
            Connection con = null;
            PreparedStatement prep = null;

            try
            {
            	 Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            	 String url="jdbc:sqlserver://localhost:49520;databaseName=Q1;integratedSecurity=true";
                con = DriverManager.getConnection(url);
                prep = con.prepareStatement(sql);
                prep.setString(1, "fn");
                prep.setString(2, "ln");
                prep.setString(3, "em");
                prep.setString(4, "ph");
                prep.setString(4, "lo");
                prep.executeUpdate();
                prep.close();

            } 
            catch (ClassNotFoundException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();

            }
            return "successfully added";
        }
        public  String update() throws SQLException
        {

            String sql = "update quest1 set lname=?,email=?,phone=?,location=? where fname=?";
            Connection con = null;
            PreparedStatement prep = null;

            try
            {
            	Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
           	    String url="jdbc:sqlserver://localhost:49520;databaseName=Q1;integratedSecurity=true";
                con = DriverManager.getConnection(url);
                prep = con.prepareStatement(sql);
                prep.setString(1, "fn");
                prep.setString(2, "ln");
                prep.setString(3, "em");
                prep.setString(4, "ph");
                prep.setString(4, "lo");
                prep.executeUpdate();
                prep.close();

            } 
            catch (ClassNotFoundException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();

            }
            return "successfully update";
        }

public  String delete() throws SQLException
    {

        String sql = "delete form quest1 where fname=?";
        Connection con = null;
        PreparedStatement prep = null;

        try
        {
        	Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
       	    String url="jdbc:sqlserver://localhost:49520;databaseName=Q1;integratedSecurity=true";
            con = DriverManager.getConnection(url);
            prep = con.prepareStatement(sql);

        } 
        catch (ClassNotFoundException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();

        }
        return "successfully delete";
    }


    }